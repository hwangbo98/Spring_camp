package com.demo.comentoStatistic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComentoStatisticApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComentoStatisticApplication.class, args);
	}

}
