package com.demo.comentoStatistic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComentoStatisticApplicationTests {

	@Test
	void contextLoads() {
	}

}
